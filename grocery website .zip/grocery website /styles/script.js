let searchForm=document.querySelector('.search-form');
document.querySelector('#search-btn').onClick=()=>{
    searchForm.classList.toggle('active')
}

